module Laboratornnaya8 {
}