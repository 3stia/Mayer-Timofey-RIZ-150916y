package Zadachi;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;

public class Zadacha5 {
	public class Files_byteRW_my2 {

		private static DataInputStream rd;

		public static void main(String[] args) { try (Scanner sc = new Scanner(System.in)) {
			System.out.print("Введите имя файла => "); String fname=sc.nextLine();
			try{
			File f1=new File(fname); f1.createNewFile();
			System.out.println("Полный путь файла:	"+ f1.getAbsolutePath());
			System.out.print("Введите количество строк для записи в файл => "); int n=sc.nextInt();
			DataOutputStream dOut=
			new DataOutputStream( new FileOutputStream(f1));
			sc.nextLine();
			for (int i = 0; i < n; i++) {
			System.out.print("Введите строку для записи в файл => "); String s=sc.nextLine();
			dOut.writeUTF(s );
			}
			dOut.flush();
			dOut.close();
			try (DataInputStream dIn = new DataInputStream(new FileInputStream(f1))) {
			} while (true) {
			rd = null;
			System.out.println(rd.readUTF());
			}
			}catch (Exception e) { System.out.println(""+e);
			}
		}}
	}
}

