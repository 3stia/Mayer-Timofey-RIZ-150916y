package Zadaniya;

public class Zadanie3{
	import java.io.*;
	import java.util.Arrays;
	import java.util.regex.Pattern;

	    private static final Pattern CONSONANT_PATTERN = Pattern.compile("[бвгджзйклмнпрстфхцчшщ]");

	    public static void main(String[] args) {
	        try (BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
	             BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"))) {
	            
	            String line;
	            int lineNumber = 1;
	            
	            while ((line = reader.readLine()) != null) {
	                String[] words = line.split("\\s+");
	                int count = 0;
	                StringBuilder result = new StringBuilder();
	                
	                for (String word : words) {
	                    if (isConsonantStart(word)) {
	                        result.append(word).append(" ");
	                        count++;
	                    }
	                }
	                
	                if (count > 0) {
	                    writer.write("Строка " + lineNumber + ": ");
	                    writer.write(result.toString());
	                    writer.write("(найдено слов: " + count + ")");
	                    writer.newLine();
	                }
	                
	                lineNumber++;
	            }
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

	    private static boolean isConsonantStart(String word) {
	        if (word.isEmpty()) return false;
	        char firstChar = Character.toLowerCase(word.charAt(0));
	        return CONSONANT_PATTERN.matcher(String.valueOf(firstChar)).matches();
	    }
	    

