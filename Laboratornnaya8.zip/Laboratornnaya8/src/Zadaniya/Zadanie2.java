package Zadaniya;

public class Zadanie2 {
	import java.io.*;
	    public static void main(String[] args) {
	        try (BufferedReader reader = new BufferedReader(new FileReader("input.txt"));
	             BufferedWriter writer = new BufferedWriter(new FileWriter("output.txt"))) {
	            reader.readLine();
	            String secondLine = reader.readLine();
	            writer.write(secondLine);
	            writer.newLine();
	            String[] numbersStr = reader.readLine().split(" ");
	            double[] numbers = new double[numbersStr.length];
	            for (int i = 0; i < numbersStr.length; i++) {
	                numbers[i] = Double.parseDouble(numbersStr[i]);
	                if (numbers[i] > 0) {
	                    writer.write(numbers[i] + " ");
	                }
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

