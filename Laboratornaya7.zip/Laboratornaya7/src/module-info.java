module Laboratornaya7 {
}