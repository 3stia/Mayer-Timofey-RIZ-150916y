package laba;

public class Zadacha3 {
	class FirstClass {
	    public int number;
	    public FirstClass(int number) {
	        this.number = number;
	    }
	    public void setNumber(int number) {
	        this.number = number;
	    }
	    public String toString() {
	        return "FirstClass: " + number;
	    }
	}
	class SecondClass extends FirstClass {
	    public char character;
	    public SecondClass(int number, char character) {
	        super(number);
	        this.character = character;
	    }
	    public void setValues(int number, char character) {
	        setNumber(number);
	        this.character = character;
	    }
	    public String toString() {
	        return "SecondClass: " + number + ", " + character;
	    }
	}
	class ThirdClass extends SecondClass {
	    public String text;
	    public ThirdClass(int number, char character, String text) {
	        super(number, character);
	        this.text = text;
	    }
	    public void setValues(int number, char character, String text) {
	        setNumber(number);
	        this.character = character;
	        this.text = text;
	    }
	    public String toString() {
	        return "ThirdClass: " + number + ", " + character + ", " + text;
	    }
	}
}