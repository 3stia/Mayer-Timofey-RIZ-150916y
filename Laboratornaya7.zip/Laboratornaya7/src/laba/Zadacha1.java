package laba;

public class Zadacha1 {
	// Суперкласс
	class SuperClass {
	    private String text;
	    
	    public SuperClass(String text) {
	        this.text = text;
	    }
	    
	    @Override
	    public String toString() {
	        return "SuperClass: " + text;
	    }

		public String getText() {
			// TODO Auto-generated method stub
			return null;
		}
	}

	// Подкласс
	class SubClass extends SuperClass {
	    private String additionalText;
	    
	    public SubClass(String text) {
	        super(text);
	    }
	    
	    public SubClass(String text, String additionalText) {
	        super(text);
	        this.additionalText = additionalText;
	    }
	    
	    @Override
	    public String toString() {
	        return "SubClass: " + super.getText() + ", " + additionalText;
	    }
	    
	    public String getText() {
	        return super.text;
	    }
	}
}

