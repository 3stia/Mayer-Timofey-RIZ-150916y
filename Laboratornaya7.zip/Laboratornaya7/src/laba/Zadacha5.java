package laba;

import laba.Zadacha4.ClassA;
import laba.Zadacha4.ClassB;
import laba.Zadacha4.ClassC;

public class Zadacha5 {
	class BaseClass {
	    private String text;
	    public BaseClass(String text) {
	        this.text = text;
	    }
	    protected void displayInfo() {
	        System.out.println("BaseClass: text = " + text);
	    }
	}
	class SubClass1 extends BaseClass {
	    protected int number;
	    public SubClass1(String text, int number) {
	        super(text);
	        this.number = number;
	    }
	    protected void displayInfo() {
	        System.out.println("SubClass1: text = " + super.text + ", number = " + number);
	    }
	}
	class SubClass2 extends BaseClass {
	    protected char symbol;
	    public SubClass2(String text, char symbol) {
	        super(text);
	        this.symbol = symbol;
	    }
	    protected void displayInfo() {
	        System.out.println("SubClass2: text = " + super.text + ", symbol = " + symbol);
	    }
	}
	public class Main {
	    public static void main(String[] args) {
	        System.out.println("Тестирование цепочки наследования:");
	        ClassA a = new ClassA('A');
	        ClassB b = new ClassB('B', "Текст B");
	        ClassC c = new ClassC('C', "Текст C", 123);
	        System.out.println(a);
	        System.out.println(b);
	        System.out.println(c);
	        System.out.println("\nТестирование второй части:");
	        BaseClass base = new BaseClass("Базовый текст");
	        SubClass1 sub1 = new SubClass1("Текст 1", 42);
	        SubClass2 sub2 = new SubClass2("Текст 2", 'X');
	        System.out.println("Прямое использование:");
	        base.displayInfo();
	        sub1.displayInfo();
	        sub2.displayInfo();
	        System.out.println("\nПолиморфное использование:");
	        BaseClass obj1 = sub1;
	        BaseClass obj2 = sub2;
	        obj1.displayInfo();
	        obj2.displayInfo();
	    }
	}
}