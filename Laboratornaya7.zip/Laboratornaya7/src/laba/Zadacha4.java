package laba;

public class Zadacha4 {
	class ClassA {
	    public char character;
	    
	    // Конструкторы для ClassA
	    public ClassA(char character) {
	        this.character = character;
	    }
	    public ClassA(ClassA obj) {
	        this.character = obj.character;
	    }
	    public String toString() {
	        return "ClassA: character = " + character;
	    }
	}
	class ClassB extends ClassA {
	    public String text;
	    
	    // Конструкторы для ClassB
	    public ClassB(char character, String text) {
	        super(character);
	        this.text = text;
	    }
	    public ClassB(ClassB obj) {
	        super(obj);
	        this.text = obj.text;
	    }
	    public String toString() {
	        return "ClassB: character = " + character + ", text = " + text;
	    }
	}
	class ClassC extends ClassB {
	    public int number;
	    
	    // Конструкторы для ClassC
	    public ClassC(char character, String text, int number) {
	        super(character, text);
	        this.number = number;
	    }
	    public ClassC(ClassC obj) {
	        super(obj);
	        this.number = obj.number;
	    }
	    public String toString() {
	        return "ClassC: character = " + character + ", text = " + text + ", number = " + number;
	    }
	}
}