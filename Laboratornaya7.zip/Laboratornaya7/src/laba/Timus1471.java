package laba;

	import java.util.*;

	public class Timus1471 {
	    private static List<List<Edge>> graph;
	    private static class Edge {
	        int to;
	        int weight;
	        public Edge(int to, int weight) {
	            this.to = to;
	            this.weight = weight;
	        }
	    }
	    private static int findDistance(int start, int end) {
	        int[] dist = new int[graph.size()];
	        Arrays.fill(dist, Integer.MAX_VALUE);
	        dist[start] = 0;
	        PriorityQueue<int[]> pq = new PriorityQueue<>((a, b) -> a[1] - b[1]);
	        pq.offer(new int[]{start, 0});
	        while (!pq.isEmpty()) {
	            int[] current = pq.poll();
	            int u = current[0];
	            int d = current[1];
	            if (u == end) return d;
	            if (d > dist[u]) continue;
	            for (Edge edge : graph.get(u)) {
	                int v = edge.to;
	                int w = edge.weight;
	                if (dist[u] + w < dist[v]) {
	                    dist[v] = dist[u] + w;
	                    pq.offer(new int[]{v, dist[v]});
	                }
	            }
	        }
	        return -1;
	    }
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int n = scanner.nextInt();
	        graph = new ArrayList<>(n);
	        for (int i = 0; i < n; i++) {
	            graph.add(new ArrayList<>());
	        }
	        for (int i = 0; i < n - 1; i++) {
	            int u = scanner.nextInt();
	            int v = scanner.nextInt();
	            int w = scanner.nextInt();
	            graph.get(u).add(new Edge(v, w));
	            graph.get(v).add(new Edge(u, w));
	        }
	        int m = scanner.nextInt();
	        for (int i = 0; i < m; i++) {
	            int start = scanner.nextInt();
	            int end = scanner.nextInt();
	            System.out.println(findDistance(start, end));
	        }
	    }
	}


