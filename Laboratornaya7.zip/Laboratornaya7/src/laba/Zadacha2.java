package laba;

public class Zadacha2 {
	// Суперкласс
	class BaseClass {
	    private String text;
	    public BaseClass(String text) {
	        this.text = text;
	    }
	    public void setText(String text) {
	        this.text = text;
	    }
	    public int getLength() {
	        return text.length();
	    }
	}
	class DerivedClass extends BaseClass {
	    public int number;
	    public DerivedClass(int number, String text) {
	        super(text);
	        this.number = number;
	    }
	    public void setText(String text) {
	        super.setText(text);
	    }
	    public void setNumber(int number) {
	        this.number = number;
	    }
	    public void setBoth() {
	    }
	    public void setBoth(String text) {
	        setText(text);
	    }
	    public void setBoth(int number) {
	        setNumber(number);
	    }
	    public void setBoth(String text, int number) {
	        setText(text);
	        setNumber(number);
	    }
	}
}
