package laba;

	import java.util.Arrays;
import java.util.Scanner;

	public class Timus2000 {
	    private static long[][] dp;
	    private static int[] array;
		private static int start2;
		private static int start1;
	    private static long[] calculateMaxScore(int left, int right, int player) {
	        if (left > right) return new long[]{0, 0};
	        if (dp[left][right] != -1) {
	            return new long[]{dp[left][right], 0};
	        }
	        long[] option1 = calculateMaxScore(left + 1, right, 1 - player);
	        long[] option2 = calculateMaxScore(left, right - 1, 1 - player);
	        long score1 = array[left] + option1[1];
	        long opponent1 = option1[0];
	        long score2 = array[right] + option2[1];
	        long opponent2 = option2[0];
	        if (score1 - opponent1 >= score2 - opponent2) {
	            dp[left][right] = score1;
	            return new long[]{score1, opponent1};
	        } else {
	            dp[left][right] = score2;
	            return new long[]{score2, opponent2};
	        }
	    }
	    public static void main(String[] args) {
	        try (Scanner scanner = new Scanner(System.in)) {
				int n = scanner.nextInt();
				array = new int[n];
				for (int i = 0; i < n; i++) {
				    array[i] = scanner.nextInt();
				}
				setStart1(scanner.nextInt() - 1);
				setStart2(scanner.nextInt() - 1);
				dp = new long[n][n];
				for (int i = 0; i < n; i++) {
				    Arrays.fill(dp[i], -1);
				}
				long[] result = calculateMaxScore(0, n - 1, 0);
				System.out.println(result[0] + " " + result[1]);
			}
	    }
		public static int getStart2() {
			return start2;
		}
		public static void setStart2(int start2) {
			Timus2000.start2 = start2;
		}
		public static int getStart1() {
			return start1;
		}
		public static void setStart1(int start1) {
			Timus2000.start1 = start1;
		}
	}


