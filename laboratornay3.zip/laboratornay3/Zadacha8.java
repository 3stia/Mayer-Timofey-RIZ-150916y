package laboratornay3;

public class Zadacha8 {
	    public static void main(String[] args) {
	        final int SIZE = 10;
	        char[] consonants = new char[SIZE];
	        char current = 'A';
	        int count = 0;
	        while (count < SIZE) {
	            if (!isVowel(current)) {
	                consonants[count] = current;
	                count++;
	            }
	            current++;
	            if (current > 'Z') {
	                break;
	            }
	        }
	        System.out.print("Согласные буквы: ");
	        for (int i = 0; i < consonants.length; i++) {
	            System.out.print(consonants[i]);
	            if (i < consonants.length - 1) {
	                System.out.print(" ");
	            }
	        }
	        System.out.println();
	    }
	    private static boolean isVowel(char c) {
	        return c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U';
	    }
	}
