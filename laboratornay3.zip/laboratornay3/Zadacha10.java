package laboratornay3;
import java.util.Arrays;
import java.util.Random;

public class Zadacha10{
    public static void main(String[] args) {
        int size = 10;
        int[] array = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(100) + 1;
        }
        System.out.println("Исходный массив (до сортировки):");
        System.out.println(Arrays.toString(array));
        Arrays.sort(array);
        for (int i = 0; i < size / 2; i++) {
            int temp = array[i];
            array[i] = array[size - 1 - i];
            array[size - 1 - i] = temp;
        }
        System.out.println("Массив после сортировки (в порядке убывания):");
        System.out.println(Arrays.toString(array));
    }
}

