package laboratornay3;

import java.util.Scanner;

public class Zadacha5 {
		    @SuppressWarnings("resource")
			public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        System.out.print("Сколько чисел суммировать? ");
		        int count = scanner.nextInt();
		        if (count <= 0) {
		            System.out.println("Введите число больше 0.");
		            return;
		        }
		        int sum = 0;
		        int found = 0;
		        int num = 1;
		        System.out.print("Числа: ");
		        for (; found < count; num++) {
		            if (num % 5 == 2 || num % 3 == 1) {
		                System.out.print(num + " ");
		                sum += num;
		                found++;
		            }
		        }
		        System.out.println("\nСумма: " + sum);
		        scanner.close();
		    }
	}
