package laboratornay3;

public class Zadacha7 {

	public static void main(String[] args) {
		        final int SIZE = 10;
		        char[] chars = new char[SIZE];
		        char currentChar = 'a';
		        for (int i = 0; i < SIZE; i++) {
		            chars[i] = currentChar;
		            currentChar += 2;
		        }
		        System.out.print("Прямой порядок: ");
		        for (int i = 0; i < chars.length; i++) {
		            System.out.print(chars[i]);
		            if (i < chars.length - 1) {
		                System.out.print(" ");
		            }
		        }
		        System.out.println();
		        System.out.print("Обратный порядок: ");
		        for (int i = chars.length - 1; i >= 0; i--) {
		            System.out.print(chars[i]);
		            if (i > 0) {
		                System.out.print(" ");
		            }
		        }
		        System.out.println();
		    }
	}
