package laboratornay3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Scanner;

public class Timus1022 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        // Считываем количество членов Совета
	        int n = scanner.nextInt();
	        
	        // Инициализируем списки:
	        // children[i] — список детей марсианина i
	        // inDegree[i] — количество родителей у марсианина i
	        List<List<Integer>> children = new ArrayList<>();
	        int[] inDegree = new int[n + 1];
	        
	        for (int i = 0; i <= n; i++) {
	            children.add(new ArrayList<>());
	        }
	        
	        // Читаем данные: для каждого марсианина список его детей
	        for (int i = 1; i <= n; i++) {
	            String line = scanner.nextLine();
	            String[] parts = line.trim().split("\\s+");
	            for (String part : parts) {
	                int child = Integer.parseInt(part);
	                if (child == 0) break; // завершающий 0
	                children.get(i).add(child);
	                inDegree[child]++; // У ребёнка появляется родитель
	            }
	        }
	        
	        // Очередь для топологической сортировки (начинаем с inDegree == 0)
	        Queue<Integer> queue = new LinkedList<>();
	        for (int i = 1; i <= n; i++) {
	            if (inDegree[i] == 0) {
	                queue.add(i);
	            }
	        }
	        
	        // Результат — порядок выступлений
	        List<Integer> result = new ArrayList<>();
	        
	        while (!queue.isEmpty()) {
	            int current = queue.poll();
	            result.add(current);
	            
	            // Уменьшаем inDegree у всех потомков текущего марсианина
	            for (int child : children.get(current)) {
	                inDegree[child]--;
	                if (inDegree[child] == 0) {
	                    queue.add(child);
	                }
	            }
	        }
	        
	        // Выводим результат
	        for (int i = 0; i < result.size(); i++) {
	            System.out.print(result.get(i));
	            if (i < result.size() - 1) System.out.print(" ");
	        }
	        scanner.close();
	    }
	}

