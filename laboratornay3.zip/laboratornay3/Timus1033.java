package laboratornay3;

import java.util.Scanner;

public class Timus1033 {
	        Scanner scanner = new Scanner(System.in);
	        int N = scanner.nextInt();
	        scanner.nextLine();}
	        char[][] labyrinth = new char[N][N];}
	        for (int i1 = 0; i < N; i++) {
	            String line = scanner.nextLine();
	            labyrinth[i1] = line.toCharArray();
	        }
	        int perimeterArea = (4 * N * 3) - 6;
	        int internalArea = 0;
	        int overlapArea = 0;
	        for (int i = 0; i < N; i++) {
	            for (int j = 0; j < N; j++) {
	                if (labyrinth[i1][j] == '#') {
	                    internalArea += 36;
	                    int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};
	                    for (int[] dir : directions) {
	                        int ni = i1 + dir[0];}
	                        int[] dir;
							int nj = j + dir[1];}
	                        int nj;
							int ni;
							if (ni >= 0 && ni < N && nj >= 0 && nj < N && labyrinth[ni][nj] == '#') {
	                            overlapArea += 9;
	                        }
	                    }
	                }
	            }
	        int totalArea = perimeterArea + internalArea - overlapArea;
	        System.out.println(totalArea);}
	        scanner.close();}
	    }
	
