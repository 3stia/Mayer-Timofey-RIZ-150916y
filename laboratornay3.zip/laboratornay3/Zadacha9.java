package laboratornay3;

import java.util.Random;
import java.util.Scanner;

public class Zadacha9 {
	public static void main(String[] args) {
	    Random random = new Random();
	    try (Scanner scanner = new Scanner(System.in)) { 
	        System.out.print("Введите размер массива: ");
	        int size = scanner.nextInt();
	        if (size <= 0) {
	            System.out.println("Размер массива должен быть положительным числом.");
	            return;
	        }
	        int[] array = new int[size];
	        System.out.print("Массив: ");
	        
	        for (int i = 0; i < size; i++) {
	            array[i] = random.nextInt(100);
	            System.out.print(array[i] + " ");
	        }
	        System.out.println();
	        
	        int minValue = array[0];
	        for (int i = 1; i < size; i++) {
	            if (array[i] < minValue) {
	                minValue = array[i];
	            }
	        } 
	        System.out.print("Минимальное значение: " + minValue + ", индексы: ");
	        boolean firstIndex = true;
	        
	        for (int i = 0; i < size; i++) {
	            if (array[i] == minValue) {
	                if (!firstIndex) {
	                    System.out.print(" ");
	                }
	                System.out.print(i);
	                firstIndex = false;
	            }
	        }
	        System.out.println();
	    }
	}
}


