package laboratornay3;

import java.util.Scanner;

public class Zadacha6 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        int size = 0;
	        while (true) {
	            System.out.print("Введите размер массива: ");
	            if (scanner.hasNextInt()) {
	                size = scanner.nextInt();
	                if (size > 0) {
	                    break;
	                } else {
	                    System.out.println("Ошибка: размер должен быть положительным числом. Попробуйте ещё раз.");
	                }
	            } else {
	                System.out.println("Ошибка: введено не число. Попробуйте ещё раз.");
	                scanner.next();
	            }
	        }
	        int[] array = new int[size];
	        int value = 2;
	        for (int i = 0; i < size; i++) {
	            array[i] = value;
	            value += 5;
	        }
	        // Вывод массива
	        System.out.print("Массив: ");
	        for (int i = 0; i < array.length; i++) {
	            System.out.print(array[i]);
	            if (i < array.length - 1) {
	                System.out.print(" ");
	            }
	        }
	        System.out.println();
	        scanner.close();
	    }
	}
