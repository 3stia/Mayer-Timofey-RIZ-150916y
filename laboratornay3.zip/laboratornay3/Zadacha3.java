package laboratornay3;

import java.util.Scanner;

public class Zadacha3 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        System.out.print("Сколько чисел Фибоначчи вывести? ");
	        int n = scanner.nextInt();
	        if (n <= 0) {
	            System.out.println("Введите число больше 0.");
	        } else if (n == 1) {
	            System.out.print("1");
	        } else if (n == 2) {
	            System.out.print("1 1");
	        } else {
	            System.out.print("1 1 ");
	            int a = 1, b = 1;
	            for (int i = 3; i <= n; i++) {
	                int next = a + b;
	                System.out.print(next + " ");
	                a = b;
	                b = next;
	            }
	        }
	        scanner.close();
	    }
	}