package Labs;

    import java.util.Scanner;

    public class example14 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Введите число: ");
            int n = scanner.nextInt();

            int prev = n - 1;
            int next = n + 1;
            int sumFirstThree = prev + n + next;
            int square = sumFirstThree * sumFirstThree;

            System.out.println(prev + " " + n + " " + next + " " + square);

            scanner.close();
        }
    }
