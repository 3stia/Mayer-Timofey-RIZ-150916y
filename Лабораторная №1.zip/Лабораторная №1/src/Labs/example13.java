package Labs;

    import java.util.Scanner;

    public class example13 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Первое число: ");
            double num1 = scanner.nextDouble();

            System.out.print("Второе число: ");
            double num2 = scanner.nextDouble();

            double sum = num1 + num2;
            System.out.println("Сумма: " + sum);

            scanner.close();
        }
    }
