package Labs;
    import java.util.Scanner;

    public class example11 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            final int CURRENT_YEAR = 2025;

            System.out.print("Введите имя: ");
            String name = scanner.nextLine();

            System.out.print("Введите год рождения: ");
            int birthYear = scanner.nextInt();

            int age = CURRENT_YEAR - birthYear;
            System.out.println("Вас зовут " + name + ", вам " + age + " лет.");

            scanner.close();
        }
    }
