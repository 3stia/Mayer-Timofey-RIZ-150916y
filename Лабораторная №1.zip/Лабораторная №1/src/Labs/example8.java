package Labs;

    import java.util.Scanner;

    public class example8 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("День недели: ");
            String dayOfWeek = scanner.nextLine();

            System.out.print("Месяц: ");
            String month = scanner.nextLine();

            System.out.print("Дата (число): ");
            int date = scanner.nextInt();

            System.out.println("Сегодня: " + dayOfWeek + ", " + date + " " + month);

            scanner.close();
        }
    }
