package Labs;

public class example1 {
    static void main(String[] args) {
        System.out.println("Привет мир!");
    }
}
