package Labs;

    import java.util.Scanner;

    public class example12 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            final int CURRENT_YEAR = 2025;

            System.out.print("Введите ваш возраст: ");
            int age = scanner.nextInt();

            int birthYear = CURRENT_YEAR - age;
            System.out.println("Вы родились в " + birthYear + " году.");

            scanner.close();
        }
    }
