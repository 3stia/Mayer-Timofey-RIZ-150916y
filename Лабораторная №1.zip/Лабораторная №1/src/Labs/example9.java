package Labs;

    import java.util.Scanner;

    public class example9 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Название месяца: ");
            String month = scanner.nextLine();

            System.out.print("Количество дней: ");
            int days = scanner.nextInt();

            System.out.println("Месяц " + month + " содержит " + days + " дней.");

            scanner.close();
        }
    }