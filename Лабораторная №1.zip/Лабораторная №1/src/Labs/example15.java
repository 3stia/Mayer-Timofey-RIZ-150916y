package Labs;

    import java.util.Scanner;

    public class example15 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Первое число: ");
            double a = scanner.nextDouble();

            System.out.print("Второе число: ");
            double b = scanner.nextDouble();

            double sum = a + b;
            double diff = a - b;

            System.out.println("Сумма: " + sum);
            System.out.println("Разность: " + diff);

            scanner.close();
        }
    }
