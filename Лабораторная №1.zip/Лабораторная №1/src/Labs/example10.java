package Labs;

    import java.util.Scanner;

    public class example10 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            final int CURRENT_YEAR = 2025;

            System.out.print("Введите год рождения: ");
            int birthYear = scanner.nextInt();

            int age = CURRENT_YEAR - birthYear;
            System.out.println("Ваш возраст: " + age + " лет.");

            scanner.close();
        }
    }
