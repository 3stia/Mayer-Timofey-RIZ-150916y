package Timus;
import java.util.Scanner;

public class Zadacha1293 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int N = scanner.nextInt();
        int A = scanner.nextInt();
        int B = scanner.nextInt();
        int areaOneSide = A * B;
        int areaBothSides = areaOneSide * 2;
        int totalArea = areaBothSides * N;
        int totalSulfide = totalArea;
        System.out.println(totalSulfide);

        scanner.close();
    }
}