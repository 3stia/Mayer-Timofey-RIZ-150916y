
public class Zadacha5 {

	public static void main(String[] args) {
		        int rows = 3;
		        int cols = 5;
		        int[][] original = new int[rows][cols];
		        int[][] transposed = new int[cols][rows];
		        for (int i = 0; i < rows; i++) {
		            for (int j = 0; j < cols; j++) {
		                original[i][j] = i * cols + j + 1;
		            }
		        }
		        for (int i = 0; i < rows; i++) {
		            for (int j = 0; j < cols; j++) {
		                transposed[j][i] = original[i][j];
		            }
		        }
		        System.out.println("Исходный массив:");
		        printArray(original);
		        System.out.println("Транспонированный массив:");
		        printArray(transposed);
		    }
		    private static void printArray(int[][] array) {
		        for (int[] row : array) {
		            for (int val : row) {
		                System.out.print(val + " ");
		            }
		            System.out.println();
		        }
		    }
	}

