import java.util.Random;
import java.util.Scanner;

public class Zadacha6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        System.out.print("Введите количество строк (от 2): ");
        int rows = scanner.nextInt();
        while (rows < 2) {
            System.out.print("Строк должно быть не менее 2. Повторите ввод: ");
            rows = scanner.nextInt();
        }
        System.out.print("Введите количество столбцов (от 2): ");
        int cols = scanner.nextInt();
        while (cols < 2) {
            System.out.print("Столбцов должно быть не менее 2. Повторите ввод: ");
            cols = scanner.nextInt();
        }
        int[][] originalArray = new int[rows][cols];
        System.out.println("\nИсходный массив:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                originalArray[i][j] = random.nextInt(99) + 1;
                System.out.printf("%4d", originalArray[i][j]);
            }
            System.out.println();
        }
        int rowToRemove = random.nextInt(rows);
        int colToRemove = random.nextInt(cols);
        System.out.println("\nУдаляется строка №" + rowToRemove);
        System.out.println("Удаляется столбец №" + colToRemove);
        int[][] newArray = new int[rows-1][cols-1];
        int newRow = 0;
        for (int i = 0; i < rows; i++) {
            if (i == rowToRemove) continue;
            int newCol = 0;
            for (int j = 0; j < cols; j++) {
                if (j == colToRemove) continue;
                newArray[newRow][newCol] = originalArray[i][j];
                newCol++;
            }
            newRow++;
        }
        System.out.println("\nМассив после удаления:");
        for (int i = 0; i < rows-1; i++) {
            for (int j = 0; j < cols-1; j++) {
                System.out.printf("%4d", newArray[i][j]);
            }
            System.out.println();
        }
        scanner.close();
    }
}
