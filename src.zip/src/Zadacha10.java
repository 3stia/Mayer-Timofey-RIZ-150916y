import java.util.Scanner;

public class Zadacha10 {
    private static final String ALPHABET = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
    
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
			System.out.print("Введите текст для шифрования: ");
			String text = scanner.nextLine();
			
			System.out.print("Введите ключ: ");
			int key = scanner.nextInt();
			
			String encrypted = encrypt(text, key);
			System.out.println("Текст после преобразования: " + encrypted);
			
			System.out.print("Выполнить обратное преобразование? (y/n): ");
			String response = scanner.next();
			
			if (response.equals("y")) {
			    String decrypted = decrypt(encrypted, key);
			    System.out.println("Дешифрованный текст: " + decrypted);
			} else if (!response.equals("n")) {
			    System.out.println("Введите корректный ответ");
			}
		}
    }
    
    private static String encrypt(String text, int key) {
        StringBuilder result = new StringBuilder();
        
        for (char c : text.toCharArray()) {
            int index = ALPHABET.indexOf(c);
            if (index != -1) {
                result.append(ALPHABET.charAt((index + key) % ALPHABET.length()));
            } else {
                result.append(c); // Если символ не входит в алфавит, оставляем как есть
            }
        }
        
        return result.toString();
    }
    
    private static String decrypt(String text, int key) {
        return encrypt(text, -key);
    }
}
