import java.util.Scanner;

public class Timus2012 {
    @SuppressWarnings("resource")
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите количество задач, которые Гриша хочет решить за первый час (1-11):");
        int f = scanner.nextInt();
        if (f < 1 || f > 11) {
            System.out.println("Ошибка: значение должно быть от 1 до 11");
            return;
        }
        int remainingTasks = 12 - f;
        int totalTime = 60 + remainingTasks * 45;
        if (totalTime <= 300) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
        scanner.close();
    }
}
