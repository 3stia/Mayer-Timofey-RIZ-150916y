import java.util.Scanner;

public class Timus1876 {
    @SuppressWarnings("resource")
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введите количество левых тапочек (a): ");
        int a = scanner.nextInt();
        System.out.print("Введите количество правых тапочек (b): ");
        int b = scanner.nextInt();
        if (a < 40 || a > 100 || b < 40 || b > 100) {
            System.out.println("Ошибка: значения должны быть от 40 до 100");
            return;
        }
        int timeLeft = 
            40 * 1 +
            (a - 40) * 2 +
            b * 2;
        int timeRight = 
            40 * 1 +
            (b - 40) * 2 +
            a * 2;
        int totalTime = timeLeft + timeRight;
        System.out.println("Общее время обувания: " + totalTime + " секунд");
        scanner.close();
    }
}
