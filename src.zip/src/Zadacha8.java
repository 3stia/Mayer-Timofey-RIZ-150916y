import java.util.Scanner;

public class Zadacha8 {
    public static void main(String[] args) {
        try (var scanner = new Scanner(System.in)) {
			System.out.print("Введите текст для шифрования: ");
			String text = scanner.nextLine();
			System.out.print("Введите ключ: ");
			int key = scanner.nextInt();
			String encrypted = encrypt(text, key);
			System.out.println("Текст после преобразования: " + encrypted);
			System.out.print("Выполнить обратное преобразование? (y/n): ");
			String response = scanner.next();
			if (response.equals("y")) {
			    String decrypted = decrypt(encrypted, key);
			    System.out.println("Дешифрованный текст: " + decrypted);
			} else if (!response.equals("n")) {
			    System.out.println("Введите корректный ответ");
			}
		}
    }
    private static String encrypt(String text, int key) {
        StringBuilder result = new StringBuilder();
        
        for (char c : text.toCharArray()) {
            if (Character.isLetter(c)) {
                char base = Character.isUpperCase(c) ? 'A' : 'a';
                result.append((char) ((c - base + key) % 26 + base));
            } else {
                result.append(c);
            }
        }
        return result.toString();
    }
    private static String decrypt(String text, int key) {
        return encrypt(text, -key);
    }
}
